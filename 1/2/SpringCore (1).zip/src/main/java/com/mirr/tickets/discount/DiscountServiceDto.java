package com.mirr.tickets.discount;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DiscountServiceDto {

    int numberOfTickets;


}
