package com.mirr.tickets.discount;

public class TotalDiscount {


}
