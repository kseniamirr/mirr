package com.mirr.tickets.events;

public enum EventRating {
    /**
     * @author Oksana_Abramova
     */

    HIGH,

    MID,

    LOW,
}
