package com.mirr.tickets.discount;

import com.mirr.tickets.events.EventServiceImpl;

import java.time.LocalDate;

public class DiscountStrategy {

   EventServiceImpl eventService;

    public boolean getBirthdayDiscount(LocalDate from, LocalDate to) {
        return eventService.airsOnDates(from, to);
    }
}
